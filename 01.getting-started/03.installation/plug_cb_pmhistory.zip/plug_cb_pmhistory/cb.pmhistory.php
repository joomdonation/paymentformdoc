<?php
/** ensure this file is being included by a parent file */

if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }
class getPmHistoryTab  extends cbTabHandler {
	/**
	 * Constructor
	 */
	function getPmHistoryTab() {
		$this->cbTabHandler();
	}
	/**
	 * Display donation history of a user
	 *
	 * @param object $tab
	 * @param object $user
	 * @param int $ui
	 */
	function getDisplayTab($tab,$user,$ui) {
		$db = & JFactory::getDBO() ;
		$cuser = & JFactory::getUser() ;
		if ($cuser->get('id') != $user->id)
			return ;
		$params = $this->params ;
		$sql = 'SELECT COUNT(*) FROM #__pf_payments WHERE published = 1 AND user_id = '.$user->id;
		$db->setQuery($sql) ;
		$total = $db->loadResult();
		$numberPayments = $params->get('number_records', 10);
		$pagingParams = $this->_getPaging(array(),array("entries_"));
		if ($pagingParams["entries_limitstart"] === null) $pagingParams["entries_limitstart"] = "0";
		if ($numberPayments > $total) $pagingParams["entries_limitstart"] = "0";
		$sql=" SELECT a.*, b.title FROM #__pf_payments AS a INNER JOIN #__pf_forms AS b ON a.form_id = b.id WHERE a.published = 1 AND a.user_id=$user->id  "
			. " Order by a.id DESC "
			. "\n LIMIT ".($pagingParams["entries_limitstart"]?$pagingParams["entries_limitstart"]:"0").",".$numberPayments;
		;
		$db->setQuery($sql) ;
		$rows = $db->loadObjectList();
		//Get currency symbol
		$sql = 'SELECT config_value FROM #__pf_configs WHERE config_key="currency_symbol"';
		$db->setQuery($sql);
		$currencySymbol = $db->loadResult();
		ob_start();
		$this->_drawPaymentHistory($rows, $currencySymbol, $pagingParams, $numberPayments, $total);
		$return = ob_get_contents();
		ob_end_clean();
		return $return;
	}

	/**
	 * Draw the output for donation history
	 *
	 * @param array $rows
	 */
	function _drawPaymentHistory($rows , $symbol, $pagingParams, $numberPayments, $total) {
		//Load language file here
		require_once JPATH_ROOT.'/components/com_pmform/Helper/Helper.php';
		OSSolution\PaymentForm\Site\Helper\Helper::loadLanguage();
		if (count($rows)) {
			?>
			<table width="100%" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>
							<?php echo JText::_('PF_NO'); ?>
						</th>
						<th>
							<?php echo JText::_('PF_FORM'); ?>
						</th>
						<th>
							<?php echo JText::_('PF_AMOUNT').' ('.$symbol.')';?>
						</th>
						<th>
							<?php echo JText::_('PF_PAYMENT_DATE') ; ?>
						</th>
						<th>
							<?php echo JText::_('PF_PAYMEMNT_METHOD'); ?>
						</th>
					</tr>
				</thead>
				<?php
				for($i=0, $n = count($rows); $i < $n; $i++) {
					$row = $rows[$i];
					?>
					<tr>
						<td>
							<?php echo ($i + 1); ?>
						</td>
						<td>
							<?php echo $row->title ; ?>
						</td>
						<td>
							<?php echo  number_format($row->amount, 2); ?>
						</td>
						<td>
							<?php echo JHTML::_('date', $row->created_date, 'm-d-Y'); ?>
						</td>
						<td>
							<?php
							echo JText::_($row->payment_method) ;
							?>
						</td>
					</tr>
					<?php
				}

				if ($total > $numberPayments) {
				?>
					<tr>
						<td colspan="5">
							<div align="center"><?php echo $this->_writePaging($pagingParams ,"entries_", $numberPayments, $total);  ?></div>
						</td>
					</tr>
				<?php
				}
				?>
			</table>
			<?php
		}
	}
}
